class Mother {
    
    int x = 10;

    void show() {
        System.out.println("Mother's x = " + x);
    }
}
