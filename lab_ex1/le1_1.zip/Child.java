class Child extends Mother {
  
  
}
