class Child {
    
    int x = 1;

    void show() {
        System.out.println("Mother's x = " + x);
    }
}
