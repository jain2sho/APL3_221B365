class Child extends Mother {
    public void show() {
        System.out.println("Child's show method");
    }
    
    public static void staticShow() {
        System.out.println("Child's static show method");
    }
}
