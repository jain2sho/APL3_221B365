class Mother {
    public void show() {
        System.out.println("Mother's show method");
    }
    public static void staticShow() {
        System.out.println("Mother's static show method");
    }
}
