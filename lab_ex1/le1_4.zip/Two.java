class Two extends One {
	Two(int x) {
		super(x);
		System.out.println("Class Two: Constructor, x = " + x);
	}
}