class One {
	One(int x) {
		System.out.println("Class One: Parameterized Constructor, x = " + x);
	}
}